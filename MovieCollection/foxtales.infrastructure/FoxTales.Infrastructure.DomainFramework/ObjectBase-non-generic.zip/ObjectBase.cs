﻿// Copyright (C) 2014 FoxTales
// Released under the MIT License

using System;
using System.ComponentModel.DataAnnotations.Schema;
using FoxTales.Infrastructure.DomainFramework.Generics;

namespace FoxTales.Infrastructure.DomainFramework
{

    public abstract class ObjectBase : ObjectBase<Guid>
    {
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public new Guid Id { get; set; }

        protected ObjectBase()
        {
            Id = IdGenerator.NewId();
        }
    }
}
